import logo from './logo.svg';
import './App.css';
import BasicGrid from './component/TestFile1';
import Grid1 from './component/TestFile2';
import Sample3 from './component/Sample3'
import Countdown from "./Countdown"

function App() {
  return (
    
    <div className="App">
        {/* <BasicGrid/> */}
        {/* <Grid1/> */}
        {/* <Countdown/> */}
        <Sample3/>
    </div>
  );
}

export default App;
