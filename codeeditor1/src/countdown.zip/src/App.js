import logo from './logo.svg';
import './App.css';
import Countdown from './Countdown';

function App() {
  return (
    <div className="App">
       <Countdown timeTillDate="04 05 2022, 5:00 pm" timeFormat="MM DD YYYY, h:mm a" />
    </div>
  );
}

export default App;
